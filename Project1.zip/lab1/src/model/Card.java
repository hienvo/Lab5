package model;

public class Card {
	private String cc_number;
	private String expiration_date;
	
	public String getCc_number() {
		return cc_number;
	}
	
	public String getExpDate() {
		return expiration_date;
	}
	
	public void setCc_number(String cc_number) {
		this.cc_number = cc_number;
	}
	
	public void setExpDate(String expiration_date) {
		this.expiration_date = expiration_date;
	}
}
