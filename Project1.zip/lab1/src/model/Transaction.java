package model;



public class Transaction {
	
	private int RoomId;
	private int customer_id;
	private int room_number;
	private double amount;
//	private int cc_number;
//	private int expiration_date;
	
	// getter methods
	public int getRoomId() {
		return RoomId;
	}
	
	public int getCustomerId() {
		return customer_id;
	}
	
	public int getRoomNumber() {
		return room_number;
	}
	
	public double getAmount() {
		return amount;
	}
	
	

	// setter methods
	public void setRoomId(int RoomId) {
		this.RoomId = RoomId;
	}
	
	public void setCustId(int customer_id) {
		this.customer_id = customer_id;
	}
	
	public void setAmount(double amount) {
		this.amount = amount;
	}


}