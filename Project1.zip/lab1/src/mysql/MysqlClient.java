package mysql;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.mysql.jdbc.MySQLConnection;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import model.Card;
import model.Customer;
import model.Room;
import model.Transaction;

public class MysqlClient{
public MysqlConnector connector;

//public mysqlconnector connector2;

	public MysqlClient(){
		connector = new MysqlConnector();
	}
	
//	public void runQueries() throws SQLException{
//
//		List<todo> a = connector.getId();
//		//boolean success;
//		for(todo b : a){
//			System.out.println(b.getId() +" " +b.getTodomsg());
//			//success = connector2.insertUser(b);
//		}
//		
//		 
//	}
	
//	public void runQueries_msg() throws SQLException{
//
//		List<todo> a = connector.getId();
//		for(todo b : a){
//			System.out.println("msg : "+ b.getTodomsg());
//		}
//	}
	
//	public void CreateTable(String name) throws SQLException{
//		//connector.createTable("user2");
//		connector.createTable(name);	
//		
//			System.out.println("Executed mysql command! Check your database!");
//		
//		
//	}
	
	
	public void insertUser(Customer customer_info) {
		boolean success = connector.insertUser(customer_info);
		if(!success){
			System.err.println("Insert failed");
		}else{
			System.out.println("Insert success!");
		}
	}
	public void insertTransaction(Customer customer_info, Room room_info, Card card_info) {
		boolean success = connector.insertTransaction( customer_info,  room_info, card_info);
		if(!success){
			System.err.println("Insert failed");
		}else{
			System.out.println("Insert success!");
		}
	}
	
//	public void DeleteUser(todo user) {
//		boolean success = connector.DeleteUser(user);
//		if(!success){
//			System.err.println("Delete failed or user ID may not in DB");
//		}else{
//			System.out.println("Delete success!");
//		}
//	}
	
	
			
	
	public static void main (String[] arg) throws SQLException
	{
		
		
        

//		POST [id] [todo message]  Insert user and message
		
//		String timeStamp = new SimpleDateFormat("yyyy/MM/dd-HH:mm:ss").format(Calendar.getInstance().getTime());
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First Name: ");
//		String FirstName = sc.next();
		String FirstName = "sfsdf";
		System.out.println("Enter Last Name: ");
//		String LastName = sc.next();
		String LastName = "Vo";
		System.out.println("Enter Phone Number: ");
//		String Number = sc.next();
		String Number = "3132132";
		System.out.println("Enter Billing Address: ");
//		String BillingAddress = sc.next();
		String BillingAddress = "321321";
		System.out.println("Enter Billing City: ");
//		String BillingCity = sc.next();
		String BillingCity = "memphis";
		System.out.println("Enter Billing State: ");
//		String BillingState = sc.next();
		String BillingState = "tn";
		System.out.println("Enter Billing Zip: ");
//		String BillingZip = sc.next();
		String BillingZip = "38104";
		System.out.println("Enter check out date: ");
//		String CheckoutDate = sc.next();
		String CheckoutDate = "32132132";
		System.out.println("Enter check in date: ");
//		String CheckinDate = sc.next();
		String CheckinDate = "321515";
		System.out.println("Enter room type: (1-Single, 2-Double, 3-Presidential ");
		int room_type = sc.nextInt();
		
//		Random rand = new Random();
		
//		int room_number= rand.nextInt();
		
		
//		System.out.println("Enter the message: ");
//		sc.nextLine();
//		String todomsg = sc.nextLine();	
		
		MysqlClient temp = new MysqlClient();
		Customer customer_info = new Customer();
		Room room_info = new Room();
		//customer_info.setInt(null);
		customer_info.setFirstName(FirstName);
		customer_info.setLastName(LastName);
		customer_info.setNumber(Number);
		customer_info.setBillingAddress(BillingAddress);
		customer_info.setBillingCity(BillingCity);
		customer_info.setBillingState(BillingState);
		customer_info.setBillingZip(BillingZip);
		customer_info.setCheckinDate(CheckoutDate);
		customer_info.setCheckoutDate(CheckinDate);
		customer_info.setCc_number("");
		
		if (room_type == 1){
			room_info.setRoomType("Single");
		}
		else if (room_type == 2)
		{
			room_info.setRoomType("Double");
		}
		else 
		{
			room_info.setRoomType("Presidential");
		}
		
		temp.insertUser(customer_info);
		Card card_info = new Card(); 
		card_info.setCc_number("121212");
		card_info.setExpDate("2112321");
		temp.insertTransaction(customer_info, room_info, card_info);
//	
	
		
		
// DELETE [id]	
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter the id to delete: ");
//		String UserID = sc.next();
//		
//		mysqlclient temp = new mysqlclient();
//		todo user = new todo();
//		user.setId(UserID);
//		temp.DeleteUser(user);
		
	
//		GET Display ID and message		
//		mysqlclient temp2 = new mysqlclient();
//		temp2.runQueries();

		
//		GET [i] Display message only		
//		MysqlClient temp3 = new MysqlClient();
//		temp3.runQueries_msg();
		
		
		
//REPLICATE[URI]
//		I'm not quiet understand how to do it. I tried a lot and coded something but It doesnt seem right.
		
		
		
		
// Create a new table if it doesn't exist			
//		MysqlClient temp3 = new MysqlClient();
//		temp3.CreateTable("user");
	
	}

	private static void setCc_Number(String string) {
		// TODO Auto-generated method stub
		
	}
		}