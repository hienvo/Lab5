package mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.sql.Timestamp;
import java.util.Date;
import model.Customer;
import model.Room;
import model.Transaction;
import model.Card;

public class MysqlConnector {
	
	public MysqlConnector() {
		try {
			// The newInstance() call is a work around for some
			// broken Java implementations

			Class.forName("com.mysql.jdbc.Driver").newInstance();
			System.out.println("JDBC driver registered");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private Connection getConnection() {
		try {
			Connection conn = DriverManager
					.getConnection("jdbc:mysql://127.0.0.1/pa1?" + "user=root&password=054810407&useSSL=false");

			System.out.println("Got Mysql database connection");
			return conn;
		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}
		return null;
	}
	
//	public List<todo> getId() throws SQLException
//	{
//		List<todo> a = new ArrayList<todo>();
//		PreparedStatement stmt = null;
//		ResultSet rs = null;
//		Connection con = null;
//		try{
//		con = getConnection();	
//		stmt = con.prepareStatement("select * from user;");
//		rs = stmt.executeQuery();
//		
//		while (rs.next()) {
//			todo b = new todo();
//			b.setId(rs.getString("id"));
//			b.setTodomsg(rs.getString("todomsg"));
//			b.setTimestamp(rs.getString("time"));
//			//System.out.println(rs.getString("id"));
//			a.add(b);
//		}
//		return a;
//		}
//		
//		catch(SQLException ex){ 
//			System.out.println("SQLException: " + ex.getMessage());
//			System.out.println("SQLState: " + ex.getSQLState());
//			System.out.println("VendorError: " + ex.getErrorCode());
//		}
//		 finally {
//
//				if (rs != null) {
//					try {
//						rs.close();
//					} catch (SQLException sqlEx) {
//					} // ignore
//
//					rs = null;
//				}
//
//				if (stmt != null) {
//					try {
//						stmt.close();
//					} catch (SQLException sqlEx) {
//					} // ignore
//
//					stmt = null;
//				}
//				if(con != null){
//					try {
//						con.close();
//					} catch (SQLException sqlEx) {
//					} // ignore
//
//					con = null;
//				}
//
//			}
//			return null;
//		}
	
	public boolean insertUser(Customer customer_info) {
		PreparedStatement stmt = null;
		PreparedStatement stmt1 = null;
		ResultSet rs = null;
		Connection con = null;
		List<Customer> a = new ArrayList<Customer>();
		String cmd;
		try {
			// Get the connection to the database
			con = getConnection();

			// Execute the query
//			stmt = con.prepareStatement("select * from customer_info;");
//			rs = stmt.executeQuery();
			
//			while (rs.next()) {
//				Customer b = new Customer();
//				b.setCustomerId(rs.getInt("id"));
//				b.setFirstName(rs.getString("first_name"));
//				b.setLastName(rs.getString("last_name"));
//				b.setTimestamp(rs.getString("time"));
//				System.out.println(rs.getString("id"));				
//				a.add(b);
				
//			}
			//String s = user.getId();
			//System.out.println(a);
			//System.out.println(user);
			  
//			for (todo b : a){
//				
//				//if (b1.getId().contains(user.getId()))
//				if (b.getId().contains(user.getId()))
//				{
//					//System.out.println("user in list");
//					cmd = "UPDATE user SET todomsg=?, time=? WHERE id=?;";
//					stmt1 = con.prepareStatement(cmd);
//					stmt1.setString(1, user.getTodomsg());
//					stmt1.setString(2, user.getTimestamp());
//					stmt1.setString(3, user.getId());
//					
//					//System.out.println(cmd);
//					break;
//				}
//				
//				else
//					
//				{
//					//System.out.println("user not in list");
					cmd = "insert into customer_info (first_name, last_name, phone_number, billing_address, billing_city, billing_state, billing_zip, checkin_date, checkout_date, cc_number) values(?,?,?,?,?,?,?,?,?,?)";
					stmt1 = con.prepareStatement(cmd);
			
					stmt1.setString(1, customer_info.getFirstName());
					stmt1.setString(2, customer_info.getLastName());
					stmt1.setString(3, customer_info.getNumber());
					stmt1.setString(4, customer_info.getBillingAddress());
					stmt1.setString(5, customer_info.getBillingCity());
					stmt1.setString(6, customer_info.getBillingState());
					stmt1.setString(7, customer_info.getBillingZip());
					stmt1.setString(8, customer_info.getCheckinDate());
					stmt1.setString(9, customer_info.getCheckoutDate());
					stmt1.setString(10, "");
					System.out.println(stmt1);
//				}
//			}
//				
			return stmt1.executeUpdate() > 0;

			
			
		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		} finally {
			// it is a good idea to release
			// resources in a finally{} block
			// in reverse-order of their creation
			// if they are no-longer needed

			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlEx) {
				} // ignore

				rs = null;
			}

			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException sqlEx) {
				} // ignore

				stmt = null;
			}
			if(con != null){
				try {
					con.close();
				} catch (SQLException sqlEx) {
				} // ignore

				con = null;
			}

		}
		return false;
	}
	

	
	public boolean insertTransaction(Customer customer_info, Room room_info, Card card_info) {
		PreparedStatement stmt = null;
		PreparedStatement stmt1 = null;
		PreparedStatement stmt2 = null;
		PreparedStatement stmt4 = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		Connection con = null;
		List<Customer> a = new ArrayList<Customer>();
		String cmd;
		try {
			// Get the connection to the database
			con = getConnection();
//			int rrr = 268;
			
			stmt = con.prepareStatement("SELECT max(id) as id FROM pa1.customer_info;");
			
			rs = stmt.executeQuery();
			if(rs.next()){
				customer_info.setId(rs.getInt("id"));
			}
			
			
			stmt = con.prepareStatement("SELECT * FROM room_info WHERE type LIKE ? AND current_occupant = 0;");
			stmt.setString(1, room_info.getRoomType());
			rs = stmt.executeQuery();
			if(rs.next()){
				room_info.setRoomNumber(rs.getInt("room_number"));
				System.out.println(room_info.getRoomId());
				
//				System.out.println(rrr);
			}
			else{
				System.out.println("Full");
				return false;
			}
							
//			}
			//String s = user.getId();
			//System.out.println(a);
			//System.out.println(user);
			  
//			for (todo b : a){
//				
//				//if (b1.getId().contains(user.getId()))
//				if (b.getId().contains(user.getId()))
//				{
//					//System.out.println("user in list");
//					cmd = "UPDATE user SET todomsg=?, time=? WHERE id=?;";
//					stmt1 = con.prepareStatement(cmd);
//					stmt1.setString(1, user.getTodomsg());
//					stmt1.setString(2, user.getTimestamp());
//					stmt1.setString(3, user.getId());
//					
//					//System.out.println(cmd);
//					break;
//				}
					
					cmd = "INSERT INTO transactions (customer_id, room_id, amount, cc_number, expiration_date) values(?,?,?,?,?)";
					stmt1 = con.prepareStatement(cmd);
					
					stmt1.setInt(1, customer_info.getId());
					stmt1.setInt(2, room_info.getRoomId());
					stmt1.setDouble(3, room_info.getRoomPrice());
					stmt1.setString(4, card_info.getCc_number());
					stmt1.setString(5, card_info.getExpDate());
					System.out.println(stmt1);
//				}
//			}
					stmt2 = con.prepareStatement("UPDATE room_info SET current_occupant = 1 WHERE room_number = ?");	
					stmt2.setInt(1, room_info.getRoomId());
//					stmt2.setInt(1, rrr);
					
			return stmt1.executeUpdate() > 0 && stmt2.executeUpdate() >0 ;

			
			
		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		} finally {
			// it is a good idea to release
			// resources in a finally{} block
			// in reverse-order of their creation
			// if they are no-longer needed

			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlEx) {
				} // ignore

				rs = null;
			}

			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException sqlEx) {
				} // ignore

				stmt = null;
			}
			if(con != null){
				try {
					con.close();
				} catch (SQLException sqlEx) {
				} // ignore

				con = null;
			}

		}
		return false;
	}
	
	}
	